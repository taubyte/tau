// Package componentbindings backs a StarlingMonkey component's env.KV /
// env.STORAGE with real Taubyte database (KV) and storage services, scoped to
// the website's project/application. It adapts the substrate's KV/storage
// interfaces to the loopback binding server (../bindings) and wires the whole
// thing onto the website component via website.EnableComponentBindings.
//
// The substrate node calls Enable once at startup with its database + storage
// services (and, optionally, a matcher policy and a secrets source). This
// package imports `website`; `website` does not import it, so there is no cycle.
package componentbindings

import (
	"bytes"
	"context"
	"errors"
	"io"
	"strings"

	datastore "github.com/ipfs/go-datastore"
	dbIface "github.com/taubyte/tau/core/services/substrate/components/database"
	storageIface "github.com/taubyte/tau/core/services/substrate/components/storage"
	"github.com/taubyte/tau/services/substrate/components/http/website"
	"github.com/taubyte/tau/services/substrate/components/http/website/bindings"
)

// kvBinding adapts a Taubyte database's KV (resolved per op — the service caches
// the instance) to bindings.KV.
type kvBinding struct {
	svc  dbIface.Service
	ctx  context.Context
	dctx dbIface.Context
}

// NewKV returns a bindings.KV backed by the database the service resolves for
// dctx (project/application/matcher).
func NewKV(svc dbIface.Service, base context.Context, dctx dbIface.Context) bindings.KV {
	return &kvBinding{svc: svc, ctx: base, dctx: dctx}
}

func (b *kvBinding) kv() (dbIface.KV, error) {
	d, err := b.svc.Database(b.dctx)
	if err != nil {
		return nil, err
	}
	return d.KV(), nil
}

func (b *kvBinding) Get(ctx context.Context, key string) ([]byte, bool, error) {
	kv, err := b.kv()
	if err != nil {
		return nil, false, err
	}
	v, err := kv.Get(ctx, key)
	if err != nil {
		if isNotFound(err) {
			return nil, false, nil
		}
		return nil, false, err
	}
	return v, true, nil
}

func (b *kvBinding) Put(ctx context.Context, key string, value []byte) error {
	kv, err := b.kv()
	if err != nil {
		return err
	}
	return kv.Put(ctx, key, value)
}

func (b *kvBinding) Delete(ctx context.Context, key string) error {
	kv, err := b.kv()
	if err != nil {
		return err
	}
	return kv.Delete(ctx, key)
}

func (b *kvBinding) List(ctx context.Context, prefix string) ([]string, error) {
	kv, err := b.kv()
	if err != nil {
		return nil, err
	}
	return kv.List(ctx, prefix)
}

// storageBinding adapts Taubyte's versioned file storage to the flat
// get/put(path) shape of bindings.Storage (latest version only).
type storageBinding struct {
	svc  storageIface.Service
	sctx storageIface.Context
}

// NewStorage returns a bindings.Storage backed by the storage the service
// resolves for sctx (project/application/matcher).
func NewStorage(svc storageIface.Service, sctx storageIface.Context) bindings.Storage {
	return &storageBinding{svc: svc, sctx: sctx}
}

func (b *storageBinding) store() (storageIface.Storage, error) {
	return b.svc.Storage(b.sctx)
}

func (b *storageBinding) Get(ctx context.Context, path string) ([]byte, string, bool, error) {
	st, err := b.store()
	if err != nil {
		return nil, "", false, err
	}
	version, err := st.GetLatestVersion(ctx, path)
	if err != nil {
		if isNotFound(err) {
			return nil, "", false, nil
		}
		return nil, "", false, err
	}
	meta, err := st.Meta(ctx, path, version)
	if err != nil {
		if isNotFound(err) {
			return nil, "", false, nil
		}
		return nil, "", false, err
	}
	rc, err := meta.Get()
	if err != nil {
		return nil, "", false, err
	}
	defer rc.Close()
	data, err := io.ReadAll(rc)
	if err != nil {
		return nil, "", false, err
	}
	return data, "", true, nil
}

func (b *storageBinding) Put(ctx context.Context, path string, data []byte) error {
	st, err := b.store()
	if err != nil {
		return err
	}
	_, err = st.AddFile(ctx, bytes.NewReader(data), path, true) // replace latest
	return err
}

func isNotFound(err error) bool {
	return errors.Is(err, datastore.ErrNotFound) ||
		strings.Contains(err.Error(), datastore.ErrNotFound.Error())
}

// Options configure Enable.
type Options struct {
	// Matcher maps a website to the database/storage resource matcher backing its
	// env.KV / env.STORAGE. Defaults to the website name (a project resource whose
	// Match equals the website name backs the bindings).
	Matcher func(*website.Website) string
	// Secrets resolves a website's env secrets/config (surfaced as env.<NAME>).
	// Nil means no secrets (there is no built-in secret store yet).
	Secrets func(*website.Website) map[string]string
}

// Enable starts the loopback binding server and wires env.KV / env.STORAGE
// (backed by db/storage, scoped per website) and secrets onto the component
// path. Call once at substrate startup when the component runtime is enabled;
// the returned server should be Closed at shutdown.
func Enable(db dbIface.Service, storage storageIface.Service, opts Options) (*bindings.Server, error) {
	server, err := bindings.NewServer()
	if err != nil {
		return nil, err
	}
	matcher := opts.Matcher
	if matcher == nil {
		matcher = func(w *website.Website) string { return w.Config().Name }
	}
	scope := func(w *website.Website) *bindings.Scope {
		m := matcher(w)
		base := w.Service().Context()
		sc := &bindings.Scope{}
		if db != nil {
			sc.KV = NewKV(db, base, dbIface.Context{
				ProjectId: w.Project(), ApplicationId: w.Application(), Matcher: m,
			})
		}
		if storage != nil {
			sc.Storage = NewStorage(storage, storageIface.Context{
				Context: base, ProjectId: w.Project(), ApplicationId: w.Application(), Matcher: m,
			})
		}
		return sc
	}
	website.EnableComponentBindings(server, scope, opts.Secrets)
	return server, nil
}
