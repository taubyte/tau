package website

import (
	"encoding/json"
	goHttp "net/http"
	"sync"

	"github.com/taubyte/tau/services/substrate/components/http/website/bindings"
)

// Component bindings wiring. A substrate that enables the component engine starts
// a loopback binding server (bindings.Server) and calls EnableComponentBindings
// with resolvers for a website's KV/storage scope and its secrets/config. This
// registers the injector (via RegisterComponentBindings) that adds the internal
// x-taubyte-bindings / x-taubyte-env headers the component shim consumes.
//
// The scope/secrets resolvers are the integration point with Taubyte's services:
// `scope` returns KV/storage bound to the website's project/application; `secrets`
// returns its env/secrets map. Either may be nil.
var (
	bindingServer  *bindings.Server
	bindingScope   func(*Website) *bindings.Scope
	bindingSecrets func(*Website) map[string]string
	bindingTokens  sync.Map // website Id -> token (string)
)

// EnableComponentBindings wires per-website KV/storage/secrets into components.
func EnableComponentBindings(server *bindings.Server, scope func(*Website) *bindings.Scope, secrets func(*Website) map[string]string) {
	bindingServer = server
	bindingScope = scope
	bindingSecrets = secrets
	RegisterComponentBindings(injectComponentBindings)
}

// injectComponentBindings sets the internal binding headers on r. Secrets go in
// x-taubyte-env (JSON); the per-website loopback endpoint URL (token minted once
// and cached) goes in x-taubyte-bindings. The shim reads and strips both.
func injectComponentBindings(w *Website, r *goHttp.Request) {
	if bindingSecrets != nil {
		if env := bindingSecrets(w); len(env) > 0 {
			if data, err := json.Marshal(env); err == nil {
				r.Header.Set("x-taubyte-env", string(data))
			}
		}
	}
	if bindingServer != nil && bindingScope != nil {
		if token := websiteBindingToken(w); token != "" {
			r.Header.Set("x-taubyte-bindings", bindingServer.URLFor(token))
		}
	}
}

// websiteBindingToken returns the website's binding token, minting and caching
// one (registered against a lazy scope resolver) on first use.
func websiteBindingToken(w *Website) string {
	id := w.config.Id
	if t, ok := bindingTokens.Load(id); ok {
		return t.(string)
	}
	token, err := bindingServer.Registry().Add(func() *bindings.Scope { return bindingScope(w) })
	if err != nil {
		return ""
	}
	if actual, loaded := bindingTokens.LoadOrStore(id, token); loaded {
		bindingServer.Registry().Remove(token) // lost the race; release ours
		return actual.(string)
	}
	return token
}
