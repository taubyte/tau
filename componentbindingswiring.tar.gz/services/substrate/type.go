package substrate

import (
	"context"
	"io"

	"github.com/taubyte/tau/core/kvdb"
	iface "github.com/taubyte/tau/core/services/substrate"
	p2pIface "github.com/taubyte/tau/core/services/substrate/components/p2p"
	"github.com/taubyte/tau/core/services/tns"
	"github.com/taubyte/tau/core/vm"
	streams "github.com/taubyte/tau/p2p/streams/service"

	"github.com/taubyte/tau/p2p/peer"
	http "github.com/taubyte/tau/pkg/http"
)

var _ iface.Service = &Service{}

// TODO: Node shouldn't have to have all
type Service struct {
	ctx        context.Context
	node       peer.Node
	http       http.Service
	vm         vm.Service
	components components

	cluster   string
	dev       bool
	verbose   bool
	databases kvdb.Factory
	stream    streams.CommandService

	tns      tns.Client
	orbitals []vm.Plugin

	cpuCount   int
	cpuAverage float64

	// componentBindings is the loopback KV/storage/secrets binding server for the
	// StarlingMonkey component engine; set only under -tags wasmtime_component.
	componentBindings io.Closer
}

// TODO: All of these components interfaces can be removed

func (n *Service) Context() context.Context {
	return n.ctx
}

func (n *Service) Node() peer.Node {
	return n.node
}

func (s *Service) Vm() vm.Service {
	return s.vm
}

func (s *Service) Http() http.Service {
	return s.http
}

func (s *Service) Counter() iface.CounterService {
	return s.components.counters
}

func (s *Service) SmartOps() iface.SmartOpsService {
	return s.components.smartops
}

func (s *Service) Tns() tns.Client {
	return s.tns
}

func (s *Service) P2P() p2pIface.Service {
	return s.components.p2p
}
